"use client";

import {
    PieChart,
    Pie,
    Tooltip,
    Cell,
    ResponsiveContainer
} from "recharts";

const COLORS = [
    "#ef4444",
    "#fb923c",
    "#eab308",
    "#22c55e"
];

export default function SeverityChart({ data }: any) {

    const chart = [

        {
            name: "Critical",
            value: data.critical
        },

        {
            name: "High",
            value: data.high
        },

        {
            name: "Medium",
            value: data.medium
        },

        {
            name: "Low",
            value: data.low
        }

    ];

    return (

        <ResponsiveContainer width="100%" height={300}>

            <PieChart>

                <Pie
                    data={chart}
                    dataKey="value"
                    outerRadius={110}
                >

                    {chart.map((_, index) => (

                        <Cell
                            key={index}
                            fill={COLORS[index]}
                        />

                    ))}

                </Pie>

                <Tooltip />

            </PieChart>

        </ResponsiveContainer>

    );
}