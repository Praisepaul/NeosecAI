"use client";

import {

BarChart,
Bar,
XAxis,
YAxis,
Tooltip,
ResponsiveContainer

} from "recharts";

export default function VendorChart({ vendors }: any) {

    return (

        <ResponsiveContainer
            width="100%"
            height={300}
        >

            <BarChart data={vendors}>

                <XAxis dataKey="vendor"/>

                <YAxis/>

                <Tooltip/>

                <Bar dataKey="count"/>

            </BarChart>

        </ResponsiveContainer>

    );

}