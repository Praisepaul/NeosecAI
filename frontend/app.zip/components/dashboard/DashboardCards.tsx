"use client";

type Props = {
    summary: {
        security_score: number;
        critical: number;
        high: number;
        matched_assets: number;
    };
};

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function DashboardCards({ summary }: Props) {
    return (
        <div className="grid grid-cols-4 gap-5">

            <Card>
                <CardHeader>
                    <CardTitle>Security Score</CardTitle>
                </CardHeader>

                <CardContent className="text-4xl font-bold">
                    {summary.security_score}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Critical</CardTitle>
                </CardHeader>

                <CardContent className="text-4xl font-bold text-red-500">
                    {summary.critical}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>High</CardTitle>
                </CardHeader>

                <CardContent className="text-4xl font-bold text-orange-500">
                    {summary.high}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Matched Assets</CardTitle>
                </CardHeader>

                <CardContent className="text-4xl font-bold">
                    {summary.matched_assets}
                </CardContent>
            </Card>

        </div>
    );
}