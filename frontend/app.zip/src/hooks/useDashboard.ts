import { useEffect, useState } from "react";
import { getDashboard } from "@/services/dashboard";

export function useDashboard() {

    const [dashboard, setDashboard] = useState<any>();

    const [loading, setLoading] = useState(true);

    useEffect(() => {

        getDashboard()

            .then(setDashboard)

            .finally(() => setLoading(false));

    }, []);

    return {

        dashboard,

        loading

    };

}