export interface DashboardSummary {

    critical: number;

    high: number;

    medium: number;

    low: number;

    kev: number;

    matched_assets: number;

    security_score: number;

    last_sync: string;

}

export interface DashboardResponse {

    summary: DashboardSummary;

    recent_threats: any[];

    top_vendors: any[];

}